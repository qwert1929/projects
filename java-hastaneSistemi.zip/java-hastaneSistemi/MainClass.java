
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class MainClass {

	public static ArrayList<Appointment> list = new ArrayList<>();

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		int selection = 0;

		while (true) {

			for (MenuItems m : MenuItems.values()) {
				System.out.println(m.getStr());
			}

			selection = sc.nextInt();
			sc.nextLine();

			if (selection == 1) {
				System.out.print("Please enter a name: ");
				String name = sc.nextLine();
				System.out.print("Please enter a surname: ");
				String surname = sc.nextLine();
				System.out.print("Please enter a field: ");
				String field = sc.nextLine();
				list.add(new Doctor(name, surname, field));
			} else if (selection == 2) {
				System.out.print("Please enter a name: ");
				String name = sc.nextLine();
				System.out.print("Please enter a surname: ");
				String surname = sc.nextLine();
				System.out.print("Please enter a ID: ");
				long ID = sc.nextLong();
				list.add(new Patient(name, surname, ID));
			} else if (selection == 3) {
				Iterator<Appointment> itd = list.iterator();
				while (itd.hasNext()) {
					Appointment a = itd.next();
					if (a instanceof Doctor) {
						Doctor d = (Doctor) a;
						d.displayInfo();
					}
				}
			} else if (selection == 4) {
				Iterator<Appointment> itd = list.iterator();
				while (itd.hasNext()) {
					Appointment a = itd.next();
					if (a instanceof Patient) {
						Patient p = (Patient) a;
						p.displayInfo();
					}
				}
			} else if (selection == 5) {
				System.out.print("Please enter a code: ");
				String code = sc.nextLine();
				list.add(new AmbulanceDepartment(code));
			} else if (selection == 6) {
				System.out.print("Please enter a code: ");
				String code = sc.nextLine();
				list.add(new FireDepartment(code));
			} else if (selection == 7) {
				Iterator<Appointment> itd = list.iterator();
				while (itd.hasNext()) {
					Appointment a = itd.next();
					if (a instanceof AmbulanceDepartment) {
						AmbulanceDepartment aD = (AmbulanceDepartment) a;
						aD.print();
					}
				}
			} else if (selection == 8) {
				Iterator<Appointment> itd = list.iterator();
				while (itd.hasNext()) {
					Appointment a = itd.next();
					if (a instanceof FireDepartment) {
						FireDepartment fD = (FireDepartment) a;
						fD.print();
					}
				}
			} else if (selection == 9) {
				Iterator<Appointment> itd = list.iterator();
				while (itd.hasNext()) {
					Appointment a = itd.next();
					a.getAppointment();
					System.out.println();
					System.out.println("-----");
					System.out.println();
				}
			} else if (selection == 0) {
				break;
			} else {
				System.out.println("Wrong selection. Please retry!");
			}

			System.out.println();

		}

	}

}
