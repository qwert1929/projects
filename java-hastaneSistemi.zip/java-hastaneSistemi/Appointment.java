
public interface Appointment {

	public void getAppointment();

}
