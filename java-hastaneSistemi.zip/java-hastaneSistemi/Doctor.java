
public class Doctor extends Person {

	private String field;

	public Doctor(String name, String surname, String field) {
		super(name, surname);
		this.field = field;
	}

	public void displayInfo() {
		System.out.println("Displaying Doctor:");
		super.displayInfo();
		System.out.println("Field is " + field);
	}

	@Override
	public void getAppointment() {
		System.out.println("Doctor " + getName() + " makes an appointment with its superior.");
	}

}
