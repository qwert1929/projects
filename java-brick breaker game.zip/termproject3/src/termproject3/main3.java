package termproject3;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Scanner;
public class main3 {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int select;
		Scanner sc = new Scanner(System.in);
		/*
		JFrame jf = new JFrame();
		jf.setTitle("level select");
		jf.setLocation(500, 200);
		jf.setSize(500, 500);
	
		jf.getContentPane().setLayout(new FlowLayout());
		JButton buton1 = new JButton("enter");
		JTextField text1 = new JTextField(25);
		JLabel label1 = new JLabel();
		label1.setText("plz select level(easy-normal-hard)");
		jf.add(label1);
		jf.getContentPane().add(text1);
		jf.getContentPane().add(buton1);
		
		buton1.addActionListener(new ActionListener() {
		
			public void actionPerformed(ActionEvent e) {
				label1.setText("selected "+ text1.getText());	
			}
		});
		jf.setVisible(true);
		jf.setResizable(false);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); */

		
		JFrame obj=new JFrame();
		Level1 lvl1 = new Level1();
		Level2 lvl2 = new Level2();
		Level3 lvl3 = new Level3();
		obj.setBounds(10, 10, 700, 600);
		obj.setTitle("arkanoid game");		
		obj.setResizable(false);
		obj.setVisible(true);
        obj.setLocationRelativeTo(null);
        obj.addKeyListener(lvl1);
		obj.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		obj.add(lvl1);
		
		/*if(text1.getText() == "easy")
			obj.add(lvl1);
		else if(text1 == "normal")
			obj.add(lvl2);
		else if(text1 == "hard")
			obj.add(lvl3); */

	}
	
}
